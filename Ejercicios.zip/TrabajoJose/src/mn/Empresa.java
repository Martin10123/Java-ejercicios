
package mn;

import java.util.ArrayList;

public class Empresa {
    private ArrayList<Bus> buses;
    private ArrayList<Conductor> conductores;
    private ArrayList<Salida> despachos;

    // Constructor
    public Empresa() {
        this.buses = new ArrayList<>();
        this.conductores = new ArrayList<>();
        this.despachos = new ArrayList<>();
    }

    // Métodos para adicionar un bus, conductor y registrar una salida
    public void adicionarBus(Bus bus) {
        buses.add(bus);
    }

    public void adicionarConductor(Conductor conductor) {
        conductores.add(conductor);
    }

    public void registrarSalida(Salida salida) {
        despachos.add(salida);
    }
    
    public ArrayList<Bus> getBuses() {
        return buses;
    }

    public ArrayList<Conductor> getConductores() {
        return conductores;
    }

    // Métodos para obtener los reportes
    public void sacarReporte1() {
        System.out.println("----- Reporte 1: Salidas de Conductores -----");
        for (Salida salida : despachos) {
            System.out.println("Conductor: " + salida.getConductor().getNombre() + " " + salida.getConductor().getApellido());
            System.out.println("Fecha: " + salida.getFecha() + " Hora: " + salida.getHora());
            System.out.println("---------------------------------------------");
        }
    }

    public void sacarReporte2() {
        System.out.println("----- Reporte 2: Salidas de Buses -----");
        for (Salida salida : despachos) {
            System.out.println("Bus: " + salida.getBus().getPlaca());
            System.out.println("Fecha: " + salida.getFecha() + " Hora: " + salida.getHora());
            System.out.println("---------------------------------------");
        }
    }
}
