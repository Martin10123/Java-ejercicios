package mn;

import java.util.Date;

public class Salida {

    private Bus bus;
    private Conductor conductor;
    private Date fecha;
    private String hora;
    private String ruta;

    // Constructor
    public Salida(Bus bus, Conductor conductor, Date fecha, String hora, String ruta) {
        this.bus = bus;
        this.conductor = conductor;
        this.fecha = fecha;
        this.hora = hora;
        this.ruta = ruta;
    }

    // Getters y Setters
    public Bus getBus() {
        return bus;
    }

    public void setBus(Bus bus) {
        this.bus = bus;
    }

    public Conductor getConductor() {
        return conductor;
    }

    public void setConductor(Conductor conductor) {
        this.conductor = conductor;
    }

    public Date getFecha() {
        return fecha;
    }

    public void setFecha(Date fecha) {
        this.fecha = fecha;
    }

    public String getHora() {
        return hora;
    }

    public void setHora(String hora) {
        this.hora = hora;
    }

    public String getRuta() {
        return ruta;
    }

    public void setRuta(String ruta) {
        this.ruta = ruta;
    }
}
