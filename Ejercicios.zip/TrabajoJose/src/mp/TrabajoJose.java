package mp;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import mn.Bus;
import mn.Conductor;
import mn.Empresa;
import mn.Salida;

import java.util.Date;
import java.util.Scanner;

public class TrabajoJose {
    private static Scanner scanner = new Scanner(System.in);
    private static Empresa empresa = new Empresa();

    public static void main(String[] args) {
        int opcion;
        do {
            mostrarMenu();
            opcion = obtenerOpcion();
            ejecutarOpcion(opcion);
        } while (opcion != 0);
    }

    private static void mostrarMenu() {
        System.out.println("----- Menú Principal -----");
        System.out.println("1. Adicionar Bus");
        System.out.println("2. Adicionar Conductor");
        System.out.println("3. Registrar Salida");
        System.out.println("4. Sacar Reporte 1");
        System.out.println("5. Sacar Reporte 2");
        System.out.println("0. Salir");
        System.out.println("--------------------------");
    }

    private static int obtenerOpcion() {
        System.out.print("Ingrese una opción: ");
        return scanner.nextInt();
    }

    private static void ejecutarOpcion(int opcion) {
        switch (opcion) {
            case 1:
                adicionarBus();
                break;
            case 2:
                adicionarConductor();
                break;
            case 3:
                registrarSalida();
                break;
            case 4:
                empresa.sacarReporte1();
                break;
            case 5:
                empresa.sacarReporte2();
                break;
            case 0:
                System.out.println("¡Hasta luego!");
                break;
            default:
                System.out.println("Opción inválida. Por favor, seleccione una opción válida.");
        }
        System.out.println();
    }

    private static void adicionarBus() {
        System.out.println("----- Adicionar Bus -----");
        System.out.print("Ingrese el ID del bus: ");
        int id = scanner.nextInt();
        scanner.nextLine();
        System.out.print("Ingrese la placa del bus: ");
        String placa = scanner.nextLine();
        System.out.print("Ingrese la marca del bus: ");
        String marca = scanner.nextLine();
        System.out.print("Ingrese la línea del bus: ");
        String linea = scanner.nextLine();
        System.out.print("Ingrese el modelo del bus: ");
        String modelo = scanner.nextLine();
        System.out.print("Ingrese la cantidad de pasajeros del bus: ");
        int cantidadDePasajeros = scanner.nextInt();

        Bus bus = new Bus(id, placa, marca, linea, modelo, cantidadDePasajeros);
        empresa.adicionarBus(bus);
        System.out.println("El bus se ha adicionado correctamente.");
    }

    private static void adicionarConductor() {
        System.out.println("----- Adicionar Conductor -----");
        System.out.print("Ingrese el ID del conductor: ");
        int id = scanner.nextInt();
        scanner.nextLine();
        System.out.print("Ingrese el nombre del conductor: ");
        String nombre = scanner.nextLine();
        System.out.print("Ingrese el apellido del conductor: ");
        String apellido = scanner.nextLine();
        System.out.print("Ingrese el número de celular del conductor: ");
        String celular = scanner.nextLine();
        System.out.print("Ingrese el tipo de sangre del conductor: ");
        String tipoSangre = scanner.nextLine();

        Conductor conductor = new Conductor(id, nombre, apellido, celular, tipoSangre);
        empresa.adicionarConductor(conductor);
        System.out.println("El conductor se ha adicionado correctamente.");
    }

    private static void registrarSalida() {
        System.out.println("----- Registrar Salida -----");
        System.out.print("Ingrese el ID del bus: ");
        int busId = scanner.nextInt();
        System.out.print("Ingrese el ID del conductor: ");
        int conductorId = scanner.nextInt();
        scanner.nextLine();
        System.out.print("Ingrese la fecha de salida (yyyy-MM-dd): ");
        String fechaString = scanner.nextLine();
        System.out.print("Ingrese la hora de salida (HH:mm): ");
        String hora = scanner.nextLine();
        System.out.print("Ingrese la ruta de la salida: ");
        String ruta = scanner.nextLine();

        Bus bus = obtenerBusPorId(busId);
        Conductor conductor = obtenerConductorPorId(conductorId);
        Date fecha = convertirStringAFecha(fechaString);

        if (bus != null && conductor != null && fecha != null) {
            Salida salida = new Salida(bus, conductor, fecha, hora, ruta);
            empresa.registrarSalida(salida);
            System.out.println("La salida se ha registrado correctamente.");
        } else {
            System.out.println("No se pudo registrar la salida. Verifique los datos ingresados.");
        }
    }

    private static Bus obtenerBusPorId(int id) {
        for (Bus bus : empresa.getBuses()) {
            if (bus.getId() == id) {
                return bus;
            }
        }
        return null;
    }

    private static Conductor obtenerConductorPorId(int id) {
        for (Conductor conductor : empresa.getConductores()) {
            if (conductor.getId() == id) {
                return conductor;
            }
        }
        return null;
    }

    private static Date convertirStringAFecha(String fechaString) {
        try {
            SimpleDateFormat formatter = new SimpleDateFormat("yyyy-MM-dd");
            return formatter.parse(fechaString);
        } catch (ParseException e) {
            e.printStackTrace();
            return null;
        }
    }
}
